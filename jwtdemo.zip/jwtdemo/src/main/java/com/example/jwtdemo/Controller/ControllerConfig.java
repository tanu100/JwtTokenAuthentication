package com.example.jwtdemo.Controller;


import com.example.jwtdemo.DTO.LoginRequestDto;
import com.example.jwtdemo.DTO.LoginResponseDto;
import com.example.jwtdemo.DTO.SignupRequestDto;
import com.example.jwtdemo.DTO.SignupResponseDto;
import com.example.jwtdemo.Models.Author;
import com.example.jwtdemo.Repository.JpaRepo;
import com.example.jwtdemo.Service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/auth")
public class ControllerConfig {

    @Autowired
    JpaRepo table;
    @Autowired
    AuthService authService;

    @GetMapping("/seeUsers") //Only Admin can see All the Users
    public ResponseEntity<List<Author>> seeUsers(){
        List<Author> users=table.findAll();
        return ResponseEntity.ok(users);
    }

    @GetMapping("/welcome")
    public ResponseEntity<String> homepage(){
        return ResponseEntity.ok( "Welcome User");
    }

    @PostMapping("/addUsers")  //Only admin can add another User
    public ResponseEntity<String> addUsers(@RequestBody Author user){
        String username=user.getUsername();
        if (table.findByUsername(username).isPresent()) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to add user");
        } else {
            table.save(user);
            return ResponseEntity.ok("User Added Sucessfully");
        }
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponseDto> login(@RequestBody LoginRequestDto loginRequestDto) {
        return ResponseEntity.ok(authService.LoginAuth(loginRequestDto));
    }

    @PostMapping("/signup")
    public ResponseEntity<SignupResponseDto> signup(@RequestBody SignupRequestDto signupRequestDto){
        SignupResponseDto response = authService.SignupAuth(signupRequestDto);
        if(response.getUsername() == null){ // means user exists
            return ResponseEntity.status(HttpStatus.CONFLICT).body(response); // 409 Conflict
        } else {
            return ResponseEntity.status(HttpStatus.CREATED).body(response); // 201 Created
        }
    }
}

package com.example.jwtdemo.Repository;


import com.example.jwtdemo.Models.Author;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface JpaRepo  extends JpaRepository<Author,Integer> {
    Optional<Author> findByUsername(String username);
    Optional<Author> findByEmail(String email);
}

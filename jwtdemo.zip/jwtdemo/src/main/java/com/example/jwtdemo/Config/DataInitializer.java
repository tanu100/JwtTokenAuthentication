package com.example.jwtdemo.Config;

import com.example.jwtdemo.Models.Author;
import com.example.jwtdemo.Repository.JpaRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private JpaRepo authorRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        // Create admin if not exists
        if (authorRepository.findByUsername("admin").isEmpty()) {
            Author admin = new Author();
            admin.setUsername("admin");
            admin.setPassword(passwordEncoder.encode("admin123"));
            admin.setRole("ROLE_ADMIN");
            admin.setEmail("admin@example.com");
            authorRepository.save(admin);
            System.out.println("Admin user created: admin / admin123 / admin@example.com");
        }

        // Create normal user if not exists
        if (authorRepository.findByUsername("user").isEmpty()) {
            Author user = new Author();
            user.setUsername("user");
            user.setPassword(passwordEncoder.encode("user123"));
            user.setRole("ROLE_USER");  // normal user role
            user.setEmail("user@example.com");
            authorRepository.save(user);
            System.out.println("Normal user created: user / user123 / user@example.com");
        }
    }
}

package com.example.jwtdemo.Models;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Authors")
@Data
@Builder
@AllArgsConstructor       // generates public all-args constructor
@NoArgsConstructor        // generates public no-args constructor (required by JPA)
public class Author {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @Column
    private String username;

    @Column(name = "password", unique = true)
    private String password;

    @Column(name = "email", unique = true)
    private String email;

    @Column
    private String role;

}
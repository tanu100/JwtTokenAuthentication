package com.example.jwtdemo.Service;


import com.example.jwtdemo.DTO.LoginRequestDto;
import com.example.jwtdemo.DTO.LoginResponseDto;
import com.example.jwtdemo.DTO.SignupRequestDto;
import com.example.jwtdemo.DTO.SignupResponseDto;
import com.example.jwtdemo.Jwt.JwtUtil;
import com.example.jwtdemo.Models.Author;
import com.example.jwtdemo.Repository.JpaRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

@Component
@Slf4j
public class AuthService {

    @Autowired
    AuthenticationManager authenticationManager;
    @Autowired
    JpaRepo table;
    @Autowired
    JwtUtil jwtutil;
    @Autowired
    PasswordEncoder passwordEncoder;


    public LoginResponseDto LoginAuth(LoginRequestDto loginRequestDto) {
        try {
            log.info("Attempting login for user: {}", loginRequestDto.getUsername());

            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            loginRequestDto.getUsername(),
                            loginRequestDto.getPassword()
                    )
            );

            log.info("Authentication successful for: {}", authentication.getPrincipal());



            CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
            String token = jwtutil.generateToken(userDetails); // you already use CustomUserDetails
            return new LoginResponseDto(token);

        } catch (BadCredentialsException ex) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid username or password");
        } catch (Exception ex) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Authentication failed");
        }
    }


    public SignupResponseDto SignupAuth(SignupRequestDto signupRequestDto) {

        String username=signupRequestDto.getUsername();

        if(table.findByUsername(username).isPresent()){
            return new SignupResponseDto(null,"User Already Exists");
        }else{
            Author user = Author.builder()
                    .username(signupRequestDto.getUsername())
                    .password(passwordEncoder.encode(signupRequestDto.getPassword()))
                    .email(signupRequestDto.getEmail())
                    .role(signupRequestDto.getRole())
                    .build();
            table.save(user);
            return new SignupResponseDto(signupRequestDto.getUsername(),"New UserName Added");
        }
    }
}

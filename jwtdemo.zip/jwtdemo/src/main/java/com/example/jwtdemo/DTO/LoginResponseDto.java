package com.example.jwtdemo.DTO;

import lombok.Getter;

public record LoginResponseDto(String token) {
}

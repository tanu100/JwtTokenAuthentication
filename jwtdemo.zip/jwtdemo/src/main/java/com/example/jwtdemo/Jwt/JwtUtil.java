package com.example.jwtdemo.Jwt;

import com.example.jwtdemo.Models.Author;
import com.example.jwtdemo.Service.CustomUserDetails;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

@Component
public class JwtUtil {

    @Value("${jwt.secretkey}")
    private String SKey;

    private SecretKey getSigningKey() {
        return Keys.hmacShaKeyFor(SKey.getBytes(StandardCharsets.UTF_8));
    }
    public String generateToken(CustomUserDetails user) {
        final long EXPIRATION_TIME = 1000 * 60 * 60 * 10; // 10 hours
        return Jwts.builder()
                .setSubject(user.getUsername())
                .claim("role", user.getRole())   // ✅ now works
                .claim("username", user.getUsername())
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                .signWith(getSigningKey(), SignatureAlgorithm.HS256)
                .compact();
    }


    public String getUsernameFromToken(String token) {
        Claims claims = Jwts.parserBuilder()
                .setSigningKey(getSigningKey())  // your SecretKey method
                .build()
                .parseClaimsJws(token)
                .getBody();

        return claims.getSubject(); // usually username/email is stored as subject
    }

    public boolean validateToken(String token, UserDetails userDetails) {
        // Extract username from token
        String username = getUsernameFromToken(token);

        // Check if token is expired
        boolean isTokenExpired = isTokenExpired(token);

        // Return true only if username matches and token is not expired
        return (username.equals(userDetails.getUsername()) && !isTokenExpired);
    }

    // Helper method to check expiration
    public boolean isTokenExpired(String token) {
        Date expiration = getExpirationDateFromToken(token);
        return expiration.before(new Date());
    }

    // Helper method to get expiration date
    public Date getExpirationDateFromToken(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(getSigningKey())
                .build()
                .parseClaimsJws(token)
                .getBody()
                .getExpiration();
    }

}

package com.example.jwtdemo.DTO;

import lombok.Data;

@Data
public class SignupRequestDto {
    private String username;
    private String password;
    private String email;
    private String role;
}

package com.example.jwtdemo.DTO;


import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Component
@Getter
@Setter
public class LoginRequestDto {  // also fixed typo in class name
    private String username;
    private String password;
}
